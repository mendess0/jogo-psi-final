﻿using System;
using System.Collections.Generic;

namespace SistemaCombateRPG
{
    // ==========================================
    // 1. INTERFACES E ITENS (ABSTRAÇÃO)
    // ==========================================

    public interface IUsavel
    {
        void Usar(Personagem alvo);
    }

    public class FrancesinhaEspecial : IUsavel
    {
        public string Nome { get; set; } = "Francesinha Especial";
        public int ValorCura { get; set; } = 50;

        public void Usar(Personagem alvo)
        {
            alvo.Vida += ValorCura;
            Console.WriteLine($"[ITEM] {alvo.Nome} comeu uma {Nome} e recuperou {ValorCura} de vida! Que poder calórico!");
        }
    }

    // ==========================================
    // 2. SISTEMA DE HABILIDADES
    // ==========================================

    public class Habilidade
    {
        public string Nome { get; set; }
        public int DanoBase { get; set; }
        public string DescricaoPersonalizada { get; set; }
        public string TipoEfeito { get; set; } // "Nenhum", "Veneno", "BuffDano"

        public Habilidade(string nome, int danoBase, string descricaoPersonalizada, string tipoEfeito = "Nenhum")
        {
            Nome = nome;
            DanoBase = danoBase;
            DescricaoPersonalizada = descricaoPersonalizada;
            TipoEfeito = tipoEfeito;
        }
    }

    // ==========================================
    // 3. CLASSE BASE ABSTRATA (ENCAPSULAMENTO)
    // ==========================================

    public abstract class Personagem
    {
        private int _vida;

        public string Nome { get; set; }

        public int Vida
        {
            get { return _vida; }
            set { _vida = Math.Max(0, value); }
        }

        // Atributos para o Sistema de Efeitos (ponto 3.4 da image_cb6748.png)
        public int TurnosEnvenenado { get; set; }
        public int DanoBonus { get; set; }

        public List<Habilidade> Habilidades { get; set; }
        public List<IUsavel> Inventario { get; set; }

        public Personagem(string nome, int vidaMax)
        {
            Nome = nome;
            Vida = vidaMax;
            TurnosEnvenenado = 0;
            DanoBonus = 0;
            Habilidades = new List<Habilidade>();
            Inventario = new List<IUsavel>();
        }

        public abstract void Atacar(Personagem alvo);

        public virtual void ReceberDano(int dano)
        {
            Vida -= dano;
            Console.WriteLine($"{Nome} recebeu {dano} de dano! (Vida restante: {Vida})");
        }

        // Processa o veneno no início do turno
        public void VerificarEfeitosTurno()
        {
            if (TurnosEnvenenado > 0)
            {
                int danoVeneno = 12;
                Vida -= danoVeneno;
                TurnosEnvenenado--;
                Console.WriteLine($"[SISTEMA DE EFEITOS - VENENO] {Nome} sofre com a azia radioativa e perde {danoVeneno} de vida! (Turnos restantes: {TurnosEnvenenado})");
            }
        }

        public void UsarHabilidade(int index, Personagem alvo)
        {
            if (index >= 0 && index < Habilidades.Count)
            {
                Habilidade hab = Habilidades[index];
                Console.WriteLine(string.Format(hab.DescricaoPersonalizada, Nome));

                // Aplica o aumento de atributos se o personagem tiver bónus acumulado
                int danoFinal = hab.DanoBase + DanoBonus;
                if (DanoBonus > 0 && hab.DanoBase > 0)
                {
                    Console.WriteLine($"[AUMENTO DE ATRIBUTOS] O ataque de {Nome} causou +{DanoBonus} de dano extra devido à Adrenalina!");
                    DanoBonus = 0; // O bónus gasta-se após desferir dano
                }

                if (danoFinal > 0)
                {
                    alvo.ReceberDano(danoFinal);
                }

                // Processamento dos efeitos (image_cb6748.png)
                if (hab.TipoEfeito == "Veneno")
                {
                    alvo.TurnosEnvenenado = 3;
                    Console.WriteLine($"[EFEITO] {alvo.Nome} contraiu uma Intoxicação Alimentar Crítica! Vai perder vida ao longo do tempo.");
                }
                else if (hab.TipoEfeito == "BuffDano")
                {
                    this.DanoBonus = 25; // Define o bónus para o próximo turno
                    Console.WriteLine($"[EFEITO] {Nome} aumentou o seu atributo de força! O próximo ataque causará +25 de dano!");
                }
            }
        }

        public void UsarItem(int index)
        {
            if (index >= 0 && index < Inventario.Count)
            {
                Inventario[index].Usar(this);
                Inventario.RemoveAt(index);
            }
            else
            {
                Console.WriteLine("Não tens mais itens deste tipo.");
            }
        }
    }

    // ==========================================
    // 4. CLASSES DERIVADAS (HERANÇA)
    // ==========================================

    // GORGONZOLA: O Tanque de Força Bruta
    public class Guerreiro : Personagem
    {
        public Guerreiro(string nome) : base(nome, 150)
        {
            Habilidades.Add(new Habilidade(
                "Barrigada Destrutiva",
                45,
                "[HABILIDADE] {0} dá um salto para a frente e atinge o inimigo em cheio com a sua enorme barriga!"
            ));

            // PONTO 3.4 - Habilidade com Efeito de AUMENTO DE ATRIBUTOS do Gorgonzola
            Habilidades.Add(new Habilidade(
                "Digestão Absoluta de Adrenalina",
                0, // Habilidade de preparação (Buff puro)
                "[HABILIDADE] {0} engole um bife cru gigante de uma só vez! Os seus músculos dilatam e a força física duplica para o próximo turno!",
                "BuffDano"
            ));

            Habilidades.Add(new Habilidade(
                "Mergulho Bala-de-Canhão",
                60,
                "[HABILIDADE] {0} dá um salto incrível para o seu tamanho e cai de rabo em cima do inimigo. Dano massivo!"
            ));

            Inventario.Add(new FrancesinhaEspecial());
        }

        public override void Atacar(Personagem alvo)
        {
            int danoFinal = 20 + DanoBonus;
            if (DanoBonus > 0)
            {
                Console.WriteLine($"[AUMENTO DE ATRIBUTOS] O soco de {Nome} foi fortalecido!");
                DanoBonus = 0;
            }
            Console.WriteLine($"[ATAQUE] {Nome} fecha o punho gigante e dá um soco no inimigo com a força de uma britadeira!");
            alvo.ReceberDano(danoFinal);
        }
    }

    // KURAMA: O Feiticeiro Gourmet Inteligente e Pesado
    public class Mago : Personagem
    {
        public Mago(string nome) : base(nome, 130)
        {
            // PONTO 3.4 - Habilidade com Efeito de VENENO do Kurama
            Habilidades.Add(new Habilidade(
                "Molho de Francesinha Radioativo",
                25,
                "[HABILIDADE] {0} conjura um molho ultra-condensado fora do prazo e derrama-o no adversário, causando queimaduras e azia química!",
                "Veneno"
            ));

            Habilidades.Add(new Habilidade(
                "Efeito Estufa do Cozido",
                56,
                "[HABILIDADE] {0} manipula as leis da termodinâmica e cria uma bolha de vapor pressurizado com o aroma denso de um Cozido à Portuguesa, sufocando o alvo!"
            ));

            // Ultimate mantido intocável e destrutivo
            Habilidades.Add(new Habilidade(
                "Singularidade de Colesterol",
                65,
                "[HABILIDADE] *** ULTIMATE *** {0} canaliza toda a densidade calórica do seu corpo pesado e invoca um mini buraco negro feito de gordura de rodízio!"
            ));

            Inventario.Add(new FrancesinhaEspecial());
        }

        public override void Atacar(Personagem alvo)
        {
            int danoFinal = 18 + DanoBonus;
            DanoBonus = 0;
            Console.WriteLine($"[ATAQUE] {Nome} calcula a resistência do ar e a energia cinética ideal para arremessar um salame inteiro com a precisão de um míssil!");
            alvo.ReceberDano(danoFinal);
        }
    }

    // ==========================================
    // 5. MOTOR DO JOGO (INTERAÇÃO EM CONSOLA)
    // ==========================================

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=================================");
            Console.WriteLine("     💥 GASTRONOMY TITANS RPG 💥 ");
            Console.WriteLine("=================================\n");

            Personagem jogador1 = new Guerreiro("Gorgonzola, o Bruto");
            Personagem jogador2 = new Mago("Kurama, o General do Banquete");

            Console.WriteLine($"Combate Épico: {jogador1.Nome} VS {jogador2.Nome}\n");

            bool turnoJogador1 = true;

            while (jogador1.Vida > 0 && jogador2.Vida > 0)
            {
                Personagem atacante = turnoJogador1 ? jogador1 : jogador2;
                Personagem defensor = turnoJogador1 ? jogador2 : jogador1;

                // SISTEMA DE EFEITOS: Aplica dano de veneno se o jogador atual estiver infetado
                atacante.VerificarEfeitosTurno();

                if (atacante.Vida <= 0)
                {
                    Console.WriteLine($"\n*** {atacante.Nome} não resistiu aos efeitos nocivos antes de conseguir jogar! ***");
                    break;
                }

                Console.WriteLine($"\n--- Turno de {atacante.Nome} (Vida: {atacante.Vida}) ---");
                Console.WriteLine("1. Atacar (Ataque Básico)");
                Console.WriteLine("2. Usar Habilidade Especial (Menu)");
                Console.WriteLine("3. Usar Item (Comer Francesinha)");
                Console.Write("Escolhe a tua ação: ");

                string escolha = Console.ReadLine();
                Console.WriteLine();

                switch (escolha)
                {
                    case "1":
                        atacante.Atacar(defensor);
                        break;

                    case "2":
                        if (atacante.Habilidades.Count > 0)
                        {
                            Console.WriteLine($"--- Habilidades de {atacante.Nome} ---");
                            for (int i = 0; i < atacante.Habilidades.Count; i++)
                            {
                                string sufixoEfeito = atacante.Habilidades[i].TipoEfeito != "Nenhum" ? $" [{atacante.Habilidades[i].TipoEfeito}]" : "";
                                Console.WriteLine($"{i + 1}. {atacante.Habilidades[i].Nome} (Dano Base: {atacante.Habilidades[i].DanoBase}){sufixoEfeito}");
                            }

                            Console.Write("Qual habilidade queres usar? (Digita o número): ");
                            string escolhaHab = Console.ReadLine();
                            Console.WriteLine();

                            if (int.TryParse(escolhaHab, out int indexHab) && indexHab >= 1 && indexHab <= atacante.Habilidades.Count)
                            {
                                atacante.UsarHabilidade(indexHab - 1, defensor);
                            }
                            else
                            {
                                Console.WriteLine("Opção inválida! Atrapalhaste-te com o peso e perdeste o turno.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Não tens habilidades disponíveis.");
                        }
                        break;

                    case "3":
                        if (atacante.Inventario.Count > 0)
                            atacante.UsarItem(0);
                        else
                            Console.WriteLine("O teu inventário está vazio! Não há mais francesinhas.");
                        break;

                    default:
                        Console.WriteLine("Ação inválida! Fiaste-te na conversa e perdeste o turno.");
                        break;
                }

                if (defensor.Vida <= 0)
                {
                    break;
                }

                turnoJogador1 = !turnoJogador1;
            }

            // Captura o fim de jogo (morte por ataque ou veneno)
            Personagem vencedor = jogador1.Vida > 0 ? jogador1 : jogador2;
            Personagem derrotado = jogador1.Vida > 0 ? jogador2 : jogador1;

            Console.WriteLine($"\n*** O combate terminou! {derrotado.Nome} foi totalmente derrotado e caiu em batalha. ***");
            Console.WriteLine($"*** {vencedor.Nome} É O GRANDE VENCEDOR DO BANQUETE! ***");

            Console.WriteLine("\nPrime a tecla ENTER para fechar o jogo...");
            Console.ReadLine();
        }
    }
}